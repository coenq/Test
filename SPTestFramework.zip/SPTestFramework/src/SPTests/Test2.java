package SPTests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class Test2 {

	WebDriver driver;	  
	
	  @BeforeClass
	  public void beforeClass() {		  
		  }
			
		
	  @Test
	  public void TestHelloWorld() {
		  
		  System.setProperty("webdriver.chrome.driver","C:\\project\\testwp\\SPTestFramework\\drivers\\chromedriver.exe");
		  driver = new ChromeDriver();
		  String baseUrl = "https://the-internet.herokuapp.com/";
		       
		  driver.get(baseUrl);
		  driver.findElement(By.linkText("Dynamic Loading")).click();
		  driver.findElement(By.linkText("Example 2: Element rendered after the fact")).click(); 
		  
		  //Click start button
		  driver.findElement(By.xpath("//button[text()='Start']")).click();
		  
		  if(driver.findElement(By.id("loading")).isDisplayed()){
			  System.out.println("Progress bar is Visible");
			  }else{
			  System.out.println("Element is InVisible");
			  }
		  
		  WebDriverWait wait = new WebDriverWait(driver, 10);
		  wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("loading")));
		  
		  if(driver.findElement(By.id("loading")).isDisplayed()){
			  System.out.println("Progress bar is still Visible");
			  }else{
			  System.out.println("Progress bar is now InVisible");
			  }
		  
		  if(driver.findElement(By.id("finish")).isDisplayed()){
			  System.out.println("Hellow World displayed");
			  }		  	  
		  Assert.assertEquals("Hello World!", driver.findElement(By.xpath("//"))));
		  //driver.findElement(By.id("finish")).isDisplayed()); 
	  }
	 

	  @AfterClass
	  public void afterClass() {
		  driver.close();
	  }

	}
