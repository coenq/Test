package SPTests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;


public class Test1 {
	
 WebDriver driver;	  
	
  @BeforeClass
  public void beforeClass() {
	  
	  }
		
	
  @Test
  public void CheckButtonIds() {
	  
	  System.setProperty("webdriver.chrome.driver","C:\\project\\testwp\\SPTestFramework\\drivers\\chromedriver.exe");
	  driver = new ChromeDriver();
	  String baseUrl = "https://the-internet.herokuapp.com/";
	       
	  driver.get(baseUrl);
	  driver.findElement(By.linkText("Challenging DOM")).click();
	  
	  WebElement eleBlue = driver.findElement(By.cssSelector("a[class='button']"));
	  WebElement eleGreen = driver.findElement(By.cssSelector("a[class='button success']"));
	  WebElement eleRed= driver.findElement(By.cssSelector("a[class='button alert']"));
	  	  
	  
	  String idBlue = eleBlue.getAttribute("id").toString();
	  String idGreen = eleGreen.getAttribute("id").toString();
	  String idRed = eleRed.getAttribute("id").toString();
	  
	  
	  
	  driver.findElement(By.cssSelector("a[class='button']")).click();
	  
	  eleBlue = driver.findElement(By.cssSelector("a[class='button']"));
	  eleGreen = driver.findElement(By.cssSelector("a[class='button success']"));
	  eleRed= driver.findElement(By.cssSelector("a[class='button alert']"));
	  
	  String nidBlue = eleBlue.getAttribute("id").toString();
	  String nidGreen = eleGreen.getAttribute("id").toString();
	  String nidRed = eleRed.getAttribute("id").toString();
	  
	  
	  if (nidBlue != idBlue) {
		  System.out.println("Blue old id <> new id " + idBlue + "<>" + nidBlue ) ;
	  }  
	  if (nidGreen != idGreen) {
		  System.out.println("Green old id <> new id " + idGreen + "<>" + nidGreen ) ;
	  }  
	  if (nidRed != idRed) {
		  System.out.println("Green old id <> new id " + idRed + "<>" + nidRed ) ;
	  }  
	  
	  Assert.assertNotEquals(idBlue, nidBlue);
	  Assert.assertNotEquals(idGreen, nidGreen);
	  Assert.assertNotEquals(idRed, nidRed);	 
	  
  }
 

  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
